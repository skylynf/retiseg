# 给本地 agent：服务器现状（2026-10-12 13:18 +0800）

这台机器就是训练服务器，主机名 `ubuntu-SYS-421GE-TNRT`。仓库在 `/home/qurr/luming/retiseg/retiseg`，远程是 `https://github.com/skylynf/retiseg.git`。本地 agent 连不上服务器，这个包代替一次 `runs/` 小文件同步。

压缩包里有本说明、`summary/` 两张表、`snapshot/` 当时的 GPU 和 git 状态，以及 `runs/` 下所有小文件。权重和概率图仍在服务器上，没有放进包里。

## 怎么用

1. 解压后先读本文件，再读 `summary/scored_metrics.tsv`（已打分）和 `summary/runs_index.tsv`（每个运行目录一行）。
2. 某个运行的原始记录在 `runs/<运行名>/`：`metrics_test.json` 是测试指标，`metrics_test.npz` 是逐图直方图（可以重算 AUPR、bootstrap），`history.jsonl` 是验证曲线，`recipe.json` 是实际配方，`environment.json` 有提交号、参数量、耗时，`console.log` 有开始行和退出行。
3. 精确 mAUPR 用 `summary.mAUPR`。`mAUPR_m2mrf_impl` 是 11 个阈值的实现，两列都留着，不要混用。
4. 论文 `docs/paper/retiseg_paper/paper/data/results.csv` 里 E2 主表仍是占位数字。服务器实测以本包的 `metrics_test.json` 为准，不要用那张 CSV 里的 E2 行当结果。
5. 本包是只读快照。正在跑的任务以服务器为准，本地改文件不会影响它们。

## 包里有、包里没有

收进来的是 `runs/` 里的 json、jsonl、yaml、log、txt、tsv、pkl，以及小于 20MB 的 npz，合计约 62 MB、1677 个文件。`docs/ops/00_进度.txt` 的当前全文也在包里（含尚未提交的段落）。

留在服务器、没有收进来的：

- 检查点 `*.pt`、`*.pth`（约 50 GB）
- 测试和验证概率图 `*.png`（约 44 GB）
- `runs/smoke/NN_idrid/nnunet_val/` 下 10 个约 190 MB 的 npz（名单在 `snapshot/excluded_large_npz.txt`）
- `dataset/`（含 prepared 图像和 `dataset/prepared.zip`）和 `pretrained/`

`.gitignore` 忽略了 `runs/`、`dataset/`、`pretrained/`。这三个目录在 GitHub 上没有任何文件。

## Git

上次成功记录的 `origin/main` 与本地 `HEAD` 相同：`9b00b6e1c927ed451755f2cae0ddbc29918dc253`（Record the scope cut and the finished L1 extraction in the paper sources）。今天再 `git fetch` 时代理返回 502，没有刷新远程。

工作区还有两处未提交：

- `docs/ops/00_进度.txt` 末尾多了 7 行，内容是 2026-10-12 09:08 停掉 B1、E1r 打分、U-Net 整批 Dice 重跑、E2c 只排 DDR。diff 在 `snapshot/00_progress.diff`。
- `official_code/HACDR-Net` 子模块工作区不干净，指针仍是记录的提交。

## 数据集（已在服务器上）

`dataset/prepared/` 现在有七个库。划分与 `docs/design/12_数据集.txt` 一致。

| 库 | 图像 | 训练 / 验证 / 测试 |
|---|---:|---|
| IDRiD | 81 | 44 / 10 / 27 |
| DDR | 757 | 383 / 149 / 225 |
| TJDR_std | 257 | 172 / 30 / 55 |
| TJDR_uwf | 304 | 209 / 37 / 58 |
| FGADR | 1842 | 1096 / 193 / 553 |
| DiaRetDB1 | 89 | 0 / 28 / 61 |
| RetinalLesions | 1593 | 951 / 164 / 478 |

09:08 那条进度写「五个独立库不在这台机器」，说的是当时。之后 `~/luming/retiseg/prepared.zip`（约 10 GB）已解压进 `dataset/prepared/`，原有的 IDRiD、DDR 没有被覆盖。压缩包挪到了 `dataset/prepared.zip`。FGADR 和 Retinal-Lesions 的许可不允许再分发，概率图也不外传。

E3a 还没启动。`pretrained/` 里没有 SAM、MedSAM、RETFound 权重，E5 冒烟开不了。

## 此刻在跑（快照时间见文首）

GPU 0 和 1 各约 37 GB，被别人的 `VLLM::Worker` 占着，利用率 0%，不是本项目的进程。本项目用 GPU 2–7。两个启动器从 09:08 起还在：

- `launch_b1.py --jobs bench/configs/bs_jobs.yaml --queue-all --seed0-only --only U-Net`（U-Net 整批 Dice 重跑，训完再打分）
- `launch_extra.py --experiment E2c`，只排了 DDR 的四项：HRNet 与 M2MRF，学习率 ×1/3 和 ×3。只训练和验证，不写测试图。

训练中：

| 运行 | 步数 | epoch | 最近一次验证 mAUPR |
|---|---|---|---|
| BS_unet_ddr_seed0 | 62700 / 83600 | epoch 300 / 400 | 0.527 |
| E2c_hrnet_ddr_seed0_lr1o3 | 9800 / 28000 | epoch 140 / 400 | 0.454 |
| E2c_hrnet_ddr_seed0_lr3 | 9800 / 28000 | epoch 140 / 400 | 0.581 |
| E2c_m2mrf_ddr_seed0_lr1o3 | 25080 / 83600 | epoch 120 / 400 | 0.432 |
| E2c_m2mrf_ddr_seed0_lr3 | 25080 / 83600 | epoch 120 / 400 | 0.413 |

U-Net IDRiD 种子 0 已经打完分（见下表 `BS_unet_idrid_seed0`）。U-Net DDR 种子 0 训完后，启动器会在空闲的 GPU 2 或 3 上打分。日志：`runs/logs/20261012_090836_bs_revise_U-Net.log`、`runs/logs/20261012_090836_extra_E2c_ddr.log`。

按 09:08 开跑时的速度粗估（只供参考，以 `history.jsonl` 最后一行为准）：U-Net DDR 大约还要一个多小时再加打分；HRNet 两项大约还要 7 到 8 小时；M2MRF 两项大约还要 9 到 10 小时。

## 已打分的测试精确 mAUPR

旧的 U-Net（逐像素配准损失）目录名带 `_registered`，保留作对照。现在的 `BS_unet_idrid_seed0` 和正在训的 `BS_unet_ddr_seed0` 是 2026-10-12 改成整批 Dice 之后的重跑。`BS_unet_ddr_seed0` 还没有测试数字。

| 运行 | mAUPR | MA | HE | EX | SE | mDice@0.5 | 测试张数 |
|---|---:|---:|---:|---:|---:|---:|---:|
| BS_deeplabv3_ddr_seed0 | 0.371 | 0.036 | 0.447 | 0.614 | 0.387 | 0.338 | 225 |
| BS_deeplabv3_ddr_seed1 | 0.380 | 0.044 | 0.469 | 0.594 | 0.414 | 0.331 | 225 |
| BS_deeplabv3_ddr_seed2 | 0.380 | 0.049 | 0.464 | 0.592 | 0.414 | 0.352 | 225 |
| BS_deeplabv3_idrid_seed0 | 0.532 | 0.090 | 0.643 | 0.734 | 0.662 | 0.470 | 27 |
| BS_deeplabv3_idrid_seed1 | 0.543 | 0.109 | 0.643 | 0.742 | 0.678 | 0.470 | 27 |
| BS_deeplabv3_idrid_seed2 | 0.536 | 0.103 | 0.639 | 0.740 | 0.662 | 0.453 | 27 |
| BS_fct_ddr_seed0 | 0.176 | 0.001 | 0.163 | 0.524 | 0.014 | 0.077 | 225 |
| BS_fct_idrid_seed0 | 0.259 | 0.077 | 0.163 | 0.684 | 0.110 | 0.147 | 27 |
| BS_fct_idrid_seed1 | 0.395 | 0.126 | 0.575 | 0.702 | 0.179 | 0.193 | 27 |
| BS_fct_idrid_seed2 | 0.241 | 0.039 | 0.175 | 0.653 | 0.097 | 0.117 | 27 |
| BS_hacdr_ddr_seed0 | 0.269 | 0.114 | 0.309 | 0.485 | 0.168 | 0.167 | 225 |
| BS_hacdr_idrid_seed0 | 0.562 | 0.359 | 0.502 | 0.827 | 0.560 | 0.503 | 27 |
| BS_hrnet_ddr_seed0 | 0.443 | 0.155 | 0.477 | 0.590 | 0.550 | 0.350 | 225 |
| BS_hrnet_ddr_seed1 | 0.457 | 0.158 | 0.520 | 0.603 | 0.546 | 0.369 | 225 |
| BS_hrnet_ddr_seed2 | 0.441 | 0.154 | 0.502 | 0.599 | 0.507 | 0.351 | 225 |
| BS_hrnet_idrid_seed0 | 0.699 | 0.446 | 0.684 | 0.884 | 0.783 | 0.605 | 27 |
| BS_hrnet_idrid_seed1 | 0.697 | 0.450 | 0.681 | 0.882 | 0.774 | 0.596 | 27 |
| BS_hrnet_idrid_seed2 | 0.704 | 0.451 | 0.682 | 0.886 | 0.795 | 0.605 | 27 |
| BS_m2mrf_ddr_seed0 | 0.380 | 0.148 | 0.402 | 0.547 | 0.422 | 0.416 | 225 |
| BS_m2mrf_ddr_seed1 | 0.369 | 0.151 | 0.410 | 0.533 | 0.381 | 0.409 | 225 |
| BS_m2mrf_ddr_seed2 | 0.357 | 0.145 | 0.406 | 0.521 | 0.356 | 0.386 | 225 |
| BS_m2mrf_idrid_seed0 | 0.650 | 0.443 | 0.615 | 0.868 | 0.675 | 0.654 | 27 |
| BS_m2mrf_idrid_seed1 | 0.651 | 0.444 | 0.639 | 0.858 | 0.663 | 0.652 | 27 |
| BS_m2mrf_idrid_seed2 | 0.668 | 0.462 | 0.631 | 0.875 | 0.705 | 0.653 | 27 |
| BS_swin_unet_ddr_seed0 | 0.432 | 0.174 | 0.479 | 0.650 | 0.424 | 0.434 | 225 |
| BS_swin_unet_ddr_seed1 | 0.429 | 0.173 | 0.454 | 0.656 | 0.432 | 0.438 | 225 |
| BS_swin_unet_ddr_seed2 | 0.431 | 0.176 | 0.432 | 0.655 | 0.461 | 0.441 | 225 |
| BS_swin_unet_idrid_seed0 | 0.692 | 0.478 | 0.709 | 0.894 | 0.685 | 0.653 | 27 |
| BS_swin_unet_idrid_seed1 | 0.688 | 0.471 | 0.709 | 0.895 | 0.678 | 0.651 | 27 |
| BS_swin_unet_idrid_seed2 | 0.686 | 0.462 | 0.701 | 0.892 | 0.687 | 0.646 | 27 |
| BS_unet_ddr_seed0_registered | 0.119 | 0.006 | 0.010 | 0.460 | 0.000 | 0.119 | 225 |
| BS_unet_ddr_seed1_registered | 0.119 | 0.007 | 0.053 | 0.415 | 0.000 | 0.116 | 225 |
| BS_unet_ddr_seed2_registered | 0.103 | 0.003 | 0.030 | 0.379 | 0.000 | 0.113 | 225 |
| BS_unet_idrid_seed0 | 0.658 | 0.406 | 0.622 | 0.896 | 0.707 | 0.646 | 27 |
| BS_unet_idrid_seed0_registered | 0.606 | 0.382 | 0.541 | 0.858 | 0.644 | 0.592 | 27 |
| BS_unet_idrid_seed1_registered | 0.566 | 0.340 | 0.526 | 0.851 | 0.547 | 0.579 | 27 |
| BS_unet_idrid_seed2_registered | 0.609 | 0.407 | 0.535 | 0.868 | 0.624 | 0.599 | 27 |
| E1r_m2mrf_idrid_seed0_bs4_a100 | 0.549 | 0.268 | 0.489 | 0.810 | 0.629 | 0.573 | 27 |
| NN_default_ddr_fold0 | 0.432 | 0.154 | 0.501 | 0.614 | 0.458 | 0.460 | 225 |
| NN_default_idrid_fold0 | 0.671 | 0.499 | 0.671 | 0.876 | 0.641 | 0.660 | 27 |
| NN_resencm_ddr_fold0 | 0.428 | 0.147 | 0.481 | 0.653 | 0.432 | 0.460 | 225 |
| NN_resencm_idrid_fold0 | 0.631 | 0.449 | 0.663 | 0.878 | 0.533 | 0.639 | 27 |

E1r（`E1r_m2mrf_idrid_seed0_bs4_a100`）用第 40000 步权重，不挑检查点。作者函数和精确 mAUPR 都在该目录的 `author_idrid_test.json` 与 `metrics_test.json`。进度笔记里的数字：作者 mIoU 41.78、mAUPR 61.19、mF 57.23；精确 mAUPR 0.549。

nnU-Net 四个任务（默认配置和 ResEnc-M，IDRiD 与 DDR，fold 0）已有 `metrics_test.json`。权重在 `runs/nnunet/`，本包只带了那边的日志和 json，没有 `checkpoint_final.pth`。

## 没有打分、也没在跑的目录

| 运行 | 状态 | 步数 | 最近验证 mAUPR |
|---|---|---|---|
| B1_deeplabv3_ddr_seed0 | 无退出行 | 15000 / 30000 | — |
| B1_deeplabv3_idrid_seed0 | 无退出行 | 17001 / 30000 | — |
| B1_hacdr_ddr_seed0 | 无退出行 | 2298 / 40000 | — |
| B1_hrnet_ddr_seed0 | 无退出行 | 6880 / 15488 | — |
| B1_m2mrf_ddr_seed0 | 无退出行 | 35040 / 60000 | — |
| B1_m2mrf_idrid_seed0 | 无退出行 | 17006 / 40000 | — |
| BS_fct_ddr_seed1 | 无退出行 | — / 521600 | — |
| BS_fct_ddr_seed2 | 无退出行 | — / 521600 | — |
| BS_hacdr_ddr_seed1 | 退出1 | 334000 / 334000 | 0.271 |
| BS_hacdr_ddr_seed2 | 退出1 | 334000 / 334000 | 0.305 |
| BS_hacdr_idrid_seed1 | 退出1 | 83000 / 83000 | 0.438 |
| BS_hacdr_idrid_seed2 | 退出1 | 83000 / 83000 | 0.418 |
| BSdiag_unet_batchdice_ddr_seed0 | 训练结束未打分 | 83600 / 83600 | 0.540 |
| BSdiag_unet_batchdice_idrid_seed0 | 训练结束未打分 | 21000 / 21000 | 0.569 |
| BSprobe_m2mrf_ddr_seed0 | 无退出行 | 83600 / 83600 | 0.540 |
| BSprobe_m2mrf_idrid_seed0 | 无退出行 | 42000 / 42000 | 0.544 |
| BSprobe_unet_ddr_seed0 | 无退出行 | 83600 / 83600 | 0.135 |
| BSprobe_unet_idrid_seed0 | 无退出行 | 42000 / 42000 | 0.423 |
| E1_m2mrf | 无日志 | — / — | — |

09:08 停掉的 B1 补位停在上次验证，`resume.pt` 还在服务器上，未完成的进未来工作。进度笔记里的位置：DeepLabv3 DDR 15000/30000、IDRiD 17001/30000，M2MRF DDR 35040/60000、IDRiD 17006/40000，HRNet DDR 6880/15488，HACDR-Net DDR 2298/40000。

种子 1、2 按 2026-10-11 的决定暂缓。FCT 的 DDR 种子 1、2 基本是空目录。HACDR 的种子 1、2 在服务器上有检查点，没有测试指标。

## 和协议有关、不要在本地改的事

看过测试指标之后，不再改预算、增强或选择规则。U-Net 改成整批 Dice 是在看诊断验证曲线之后、由用户决定的，写在 `bench/configs/bs_frozen.yaml` 的 `recipe_revisions`，对应提交在 9b00b6e 之前的历史里。正在跑的 U-Net 和 E2c 都记着启动时的提交 `9b00b6e`。

主表训练只在 IDRiD 和 DDR。独立测试（TJDR、FGADR、DiaRetDB1、Retinal-Lesions）的推理还没跑。
