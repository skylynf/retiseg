RetiSeg clinical review - demo (M2MRF author weights on IDRiD)

4 images, 18 marked regions.

How to open
  1. Keep this folder together (index.html, pack.js, images/, heat/).
  2. Double-click index.html. Chrome, Edge or Firefox are recommended; a laptop screen of 13 inches or more.
     If the page says it cannot find the pack, click "Open pack folder" and choose this folder.
  3. Enter your reader code (given to you by the study team) and follow the steps on the right.

Saving
  Every answer is saved automatically in this browser on this computer. Use "Export results" at the end of
  each session and send the downloaded .json file to the study team. In Chrome or Edge you can also link a
  file once ("Save to file...") so the tool keeps writing to it.
  If you move to another computer, import your last exported file there before continuing.

Please do not share this folder outside the study: some images are licensed for research use by the
study team only. Delete it when the study team tells you the review is closed.
